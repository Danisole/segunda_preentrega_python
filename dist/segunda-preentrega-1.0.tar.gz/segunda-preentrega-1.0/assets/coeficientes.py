def coeficiente_gold(a):
    return a /5.674

def coeficiente_black(a):
    return a /3.563