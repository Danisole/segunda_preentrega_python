from setuptools import setup

setup(

    name= "segunda-preentrega",
    version= "1.0",
    description="Paquete preentrega 2 Daniela Reta",
    author="La Dani",
    packages=["assets"]
)