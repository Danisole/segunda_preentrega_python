## Segunda Pre entrega de Python :clipboard:

##### La segunda pre entrega del curso de python de CoderHouse dictado por el prof. Franco Gabriel Di Martino y por el tutor Enzo Martin Zotti tuvo como tema principar crear class y objetos con el eje Cliente. Las consignas fueron las siguientes

#### Objetivo 
##### Practicar el concepto de Clases y Objetos.

#### Consigna

- Crear un programa que permita el modelamiento de Clientes en una página de compras. Se debe utilizar el concepto de Programación Orientada a Objetos y lo aprendido en clase.
- Se evaluará el uso correcto de atributos y métodos.
- Utilizar los conceptos aprendidos en la clase 15 y crear un paquete redistribuible con el programa creado."

#### Formato  

##### El proyecto debe ser un archivo comprimido del paquete. Formatos aceptados: .zip o .tar.gz bajo el nombre “Segunda pre-entrega+Apellido”.

#### Pasos :gear:

 ##### 1. Para la confección de este entregable se realizo un diagrama de clases como guia ([diagrama](https://drive.google.com/file/d/1JxXkR4UDlpRlgr2GgJE28bMgUQhCkTTj/view))

 ##### 2. Para llevarlo a codigo se uso el editor de codigo Visual Studio Code donde se instalo la extension Python que podemos encontrar en la galeria de extensiones

 ##### 3. Con la guia del diagrama se fueron llevando a codigo los anteriormente planteado tratando de usarse la mayor cantidad de conceptos vistos en clase. El fin de esto es poder aprovechar todo lo dictado por los profesores.

 ##### 4. egg u dry agregar 

 ##### 5. Comprimir

 ###### Todo esto y mas podras ver en mi [GitHub](https://github.com/Danisole/) 
